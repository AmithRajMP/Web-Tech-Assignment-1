COMP249 Assignment 1
====================

This directory contains the starter files for Assignment 1 for COMP249 in 2018.

Your task is to design the HTML and CSS for our new Job Posting site. You
are provided with a basic page outline containing a number of job listings. You must modify
the HTML and CSS to create a pleasing design.

You are free to change anything you want in this starter pack. The only constraint is that
you are designing the front page of a job listing web application.  You can (and should) 
include more in the page than just the job listings. Look at other job sites for
inspiration but make your design unique.
